Chat
====

Basic chat app built with Google Appengine.

To run locally (make sure you have the [App Engine SDK](https://cloud.google.com/appengine/downloads#Google_App_Engine_SDK_for_Python) installed): 

1. `git clone https://github.com/dbh937/chat-demo.git`
2. `cd chat-demo`
3. `dev_appserver.py davishaupt-chat`
4.  visit `localhost:8080`

Hosted at [http://davishaupt-chat.appspot.com/](http://davishaupt-chat.appspot.com/)
